package emp;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class Registration extends HttpServlet {
        @Override
        protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        	String name = req.getParameter("name");
        	String password = req.getParameter("Password");
        	String age =req.getParameter("age");
        	String email=req.getParameter("email");
        	String select=req.getParameter("select");
        	String date=req.getParameter("date");
        	String gender=req.getParameter("gender");
           
        	
        	System.out.println("name--"+name);
        	System.out.println("password--"+password);
        	System.out.println("age--"+age);
        	System.out.println("email--"+email);
        	System.out.println("select--"+select);
        	System.out.println("date--"+date);
        	System.out.println("gender--"+gender);
        	
        	String url="jdbc:mysql://localhost:3306/sys";
        	String username="root";
        	String password1="Xworkzodc@123";
        	
        	
        	try {
        		Class.forName("com.mysql.jdbc.cj.Driver");
        
        	Connection con=DriverManager.getConnection(url,username,password1);
        	PreparedStatement pst=con.prepareStatement("insert into servletvalues(?,?,?,?)");
        		
        	pst.setString(1,name);
        	pst.setString(2, password);
        	pst.setString(3, age);
        	pst.setString(4, email);
        	pst.setString(5, select);
        	pst.setString(6, date);
        	pst.setString(7, gender);
        	
        	int result=pst.executeUpdate();
        	
        	
        	
        	}catch(Exception e) {
        		e.printStackTrace();
        	}
        	
        	resp.getWriter().print("--employee data inserted");
        	
        		
            
        	
        	
        }
}
